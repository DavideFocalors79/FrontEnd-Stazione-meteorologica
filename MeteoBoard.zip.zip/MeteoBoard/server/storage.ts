import {
  type WeatherData,
  type InsertWeatherData,
  type Alert,
  type InsertAlert,
  type UserSettings,
  type InsertUserSettings,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  // Weather data
  getLatestWeatherData(): Promise<WeatherData | undefined>;
  getWeatherDataByTimeRange(startTime: Date, endTime: Date): Promise<WeatherData[]>;
  insertWeatherData(data: InsertWeatherData, timestamp?: Date): Promise<WeatherData>;
  
  // Alerts
  getAllAlerts(): Promise<Alert[]>;
  getAlert(id: string): Promise<Alert | undefined>;
  createAlert(alert: InsertAlert): Promise<Alert>;
  updateAlert(id: string, alert: Partial<Alert>): Promise<Alert | undefined>;
  deleteAlert(id: string): Promise<boolean>;
  
  // User settings
  getUserSettings(): Promise<UserSettings | undefined>;
  updateUserSettings(settings: Partial<InsertUserSettings>): Promise<UserSettings>;
}

export class MemStorage implements IStorage {
  private weatherData: Map<string, WeatherData>;
  private alerts: Map<string, Alert>;
  private settings: UserSettings | null;

  constructor() {
    this.weatherData = new Map();
    this.alerts = new Map();
    this.settings = null;
  }

  // Weather data methods
  async getLatestWeatherData(): Promise<WeatherData | undefined> {
    const sorted = Array.from(this.weatherData.values()).sort(
      (a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()
    );
    return sorted[0];
  }

  async getWeatherDataByTimeRange(startTime: Date, endTime: Date): Promise<WeatherData[]> {
    return Array.from(this.weatherData.values()).filter((data) => {
      const timestamp = new Date(data.timestamp);
      return timestamp >= startTime && timestamp <= endTime;
    }).sort((a, b) => new Date(a.timestamp).getTime() - new Date(b.timestamp).getTime());
  }

  async insertWeatherData(insertData: InsertWeatherData, timestamp?: Date): Promise<WeatherData> {
    const id = randomUUID();
    const data: WeatherData = {
      ...insertData,
      id,
      timestamp: timestamp || new Date(),
    };
    this.weatherData.set(id, data);
    
    // Keep only last 30 days of data to prevent memory issues
    const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 60 * 60 * 1000);
    for (const [key, value] of this.weatherData.entries()) {
      if (new Date(value.timestamp) < thirtyDaysAgo) {
        this.weatherData.delete(key);
      }
    }
    
    return data;
  }

  // Alert methods
  async getAllAlerts(): Promise<Alert[]> {
    return Array.from(this.alerts.values());
  }

  async getAlert(id: string): Promise<Alert | undefined> {
    return this.alerts.get(id);
  }

  async createAlert(insertAlert: InsertAlert): Promise<Alert> {
    const id = randomUUID();
    const alert: Alert = {
      ...insertAlert,
      id,
      createdAt: new Date(),
    };
    this.alerts.set(id, alert);
    return alert;
  }

  async updateAlert(id: string, updates: Partial<Alert>): Promise<Alert | undefined> {
    const alert = this.alerts.get(id);
    if (!alert) return undefined;
    
    const updated = { ...alert, ...updates };
    this.alerts.set(id, updated);
    return updated;
  }

  async deleteAlert(id: string): Promise<boolean> {
    return this.alerts.delete(id);
  }

  // Settings methods
  async getUserSettings(): Promise<UserSettings | undefined> {
    return this.settings || undefined;
  }

  async updateUserSettings(updates: Partial<InsertUserSettings>): Promise<UserSettings> {
    if (!this.settings) {
      this.settings = {
        id: randomUUID(),
        temperatureUnit: "celsius",
        speedUnit: "kmh",
        pressureUnit: "hpa",
        precipitationUnit: "mm",
        theme: "dark",
        language: "it",
        updateInterval: 180,
        stationName: "Stazione Meteo",
        stationLocation: "",
        ...updates,
      };
    } else {
      this.settings = { ...this.settings, ...updates };
    }
    return this.settings;
  }
}

export const storage = new MemStorage();
