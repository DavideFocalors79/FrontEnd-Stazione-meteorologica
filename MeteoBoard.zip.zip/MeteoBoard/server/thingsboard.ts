import axios, { AxiosInstance } from "axios";
import { InsertWeatherData } from "@shared/schema";

interface ThingsBoardConfig {
  url: string;
  token: string;
  deviceId: string;
}

interface TelemetryResponse {
  [key: string]: Array<{
    ts: number;
    value: string | number;
  }>;
}

export class ThingsBoardClient {
  private client: AxiosInstance;
  private deviceId: string;
  private isConfigured: boolean;

  constructor(config?: ThingsBoardConfig) {
    this.isConfigured = !!(config?.url && config?.token && config?.deviceId);
    this.deviceId = config?.deviceId || "";

    if (this.isConfigured && config) {
      this.client = axios.create({
        baseURL: config.url,
        headers: {
          "Content-Type": "application/json",
          "X-Authorization": `Bearer ${config.token}`,
        },
        timeout: 10000,
      });
    } else {
      // Create a dummy client for when ThingsBoard is not configured
      this.client = axios.create();
    }
  }

  async getLatestTelemetry(): Promise<InsertWeatherData | null> {
    if (!this.isConfigured) {
      console.log("ThingsBoard not configured, using mock data");
      return null;
    }

    try {
      const response = await this.client.get<TelemetryResponse>(
        `/api/plugins/telemetry/DEVICE/${this.deviceId}/values/timeseries`,
        {
          params: {
            keys: "temperature,humidity,pressure,windSpeed,windDirection,rainfall,uvIndex",
          },
        }
      );

      return this.parseTelemetryResponse(response.data);
    } catch (error) {
      console.error("Error fetching ThingsBoard telemetry:", error);
      throw new Error("Failed to fetch data from ThingsBoard");
    }
  }

  async getHistoricalTelemetry(
    startTs: number,
    endTs: number
  ): Promise<InsertWeatherData[]> {
    if (!this.isConfigured) {
      return [];
    }

    try {
      const response = await this.client.get<TelemetryResponse>(
        `/api/plugins/telemetry/DEVICE/${this.deviceId}/values/timeseries`,
        {
          params: {
            keys: "temperature,humidity,pressure,windSpeed,windDirection,rainfall,uvIndex",
            startTs,
            endTs,
            limit: 1000,
          },
        }
      );

      return this.parseHistoricalTelemetryResponse(response.data);
    } catch (error) {
      console.error("Error fetching historical ThingsBoard data:", error);
      throw new Error("Failed to fetch historical data from ThingsBoard");
    }
  }

  private parseTelemetryResponse(data: TelemetryResponse): InsertWeatherData {
    const getValue = (key: string): number => {
      const values = data[key];
      if (!values || values.length === 0) return 0;
      return Number(values[0].value);
    };

    return {
      temperature: getValue("temperature"),
      humidity: getValue("humidity"),
      pressure: getValue("pressure"),
      windSpeed: getValue("windSpeed"),
      windDirection: getValue("windDirection"),
      rainfall: getValue("rainfall"),
      uvIndex: getValue("uvIndex"),
    };
  }

  private parseHistoricalTelemetryResponse(data: TelemetryResponse): InsertWeatherData[] {
    // Get the first key to determine the number of data points
    const firstKey = Object.keys(data)[0];
    if (!firstKey || !data[firstKey]) return [];

    const dataPoints: InsertWeatherData[] = [];
    const length = data[firstKey].length;

    for (let i = 0; i < length; i++) {
      dataPoints.push({
        temperature: Number(data.temperature?.[i]?.value || 0),
        humidity: Number(data.humidity?.[i]?.value || 0),
        pressure: Number(data.pressure?.[i]?.value || 0),
        windSpeed: Number(data.windSpeed?.[i]?.value || 0),
        windDirection: Number(data.windDirection?.[i]?.value || 0),
        rainfall: Number(data.rainfall?.[i]?.value || 0),
        uvIndex: Number(data.uvIndex?.[i]?.value || 0),
      });
    }

    return dataPoints;
  }

  isReady(): boolean {
    return this.isConfigured;
  }
}

// Initialize ThingsBoard client with environment variables
export const thingsBoardClient = new ThingsBoardClient({
  url: process.env.THINGSBOARD_URL || "",
  token: process.env.THINGSBOARD_TOKEN || "",
  deviceId: process.env.THINGSBOARD_DEVICE_ID || "",
});
