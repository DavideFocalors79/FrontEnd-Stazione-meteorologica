import { WeatherData, InsertWeatherData } from "@shared/schema";

// Generate mock historical data for demo when ThingsBoard is not configured
export function generateMockHistoricalData(hours: number): InsertWeatherData[] {
  const now = new Date();
  const data: InsertWeatherData[] = [];
  
  for (let i = hours - 1; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000);
    const hour = timestamp.getHours();
    
    // Create realistic daily temperature pattern
    const baseTemp = 18;
    const tempVariation = 8 * Math.sin((hour - 6) * Math.PI / 12);
    const temp = baseTemp + tempVariation + (Math.random() - 0.5) * 2;
    
    data.push({
      temperature: parseFloat(temp.toFixed(1)),
      humidity: 55 + Math.random() * 30,
      pressure: 1013 + (Math.random() - 0.5) * 20,
      windSpeed: 10 + Math.random() * 20,
      windDirection: Math.floor(Math.random() * 360),
      rainfall: Math.random() > 0.8 ? Math.random() * 5 : 0,
      uvIndex: hour >= 6 && hour <= 18 ? Math.max(0, 8 - Math.abs(hour - 12)) : 0,
    });
  }
  
  return data;
}
