import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { thingsBoardClient } from "./thingsboard";
import { insertWeatherDataSchema, insertAlertSchema } from "@shared/schema";
import { generateMockHistoricalData } from "./weatherUtils";

let updateInterval: NodeJS.Timeout | null = null;

// Function to fetch and store data from ThingsBoard
async function fetchAndStoreWeatherData() {
  try {
    if (thingsBoardClient.isReady()) {
      const telemetry = await thingsBoardClient.getLatestTelemetry();
      if (telemetry) {
        await storage.insertWeatherData(telemetry);
        console.log("Weather data updated from ThingsBoard");
      }
    } else {
      // Generate mock data when ThingsBoard is not configured
      const mockData = generateMockHistoricalData(1)[0];
      await storage.insertWeatherData({
        temperature: mockData.temperature,
        humidity: mockData.humidity,
        pressure: mockData.pressure,
        windSpeed: mockData.windSpeed,
        windDirection: mockData.windDirection,
        rainfall: mockData.rainfall || 0,
        uvIndex: mockData.uvIndex || 0,
      });
      console.log("Mock weather data generated (ThingsBoard not configured)");
    }
  } catch (error) {
    console.error("Error fetching weather data:", error);
  }
}

export async function registerRoutes(app: Express): Promise<Server> {
  // Get current weather data
  app.get("/api/weather/current", async (_req, res) => {
    try {
      const data = await storage.getLatestWeatherData();
      
      if (!data) {
        // If no data exists, fetch and return new data
        await fetchAndStoreWeatherData();
        const newData = await storage.getLatestWeatherData();
        return res.json(newData);
      }
      
      res.json(data);
    } catch (error) {
      console.error("Error getting current weather:", error);
      res.status(500).json({ error: "Failed to fetch current weather data" });
    }
  });

  // Get historical weather data
  app.get("/api/weather/historical", async (req, res) => {
    try {
      const hours = parseInt(req.query.hours as string) || 168; // Default 7 days
      const endTime = new Date();
      const startTime = new Date(endTime.getTime() - hours * 60 * 60 * 1000);

      let data = await storage.getWeatherDataByTimeRange(startTime, endTime);

      // If no historical data, generate mock data
      if (data.length === 0) {
        const mockData = generateMockHistoricalData(hours);
        const now = new Date();
        for (let i = 0; i < mockData.length; i++) {
          const item = mockData[i];
          const timestamp = new Date(now.getTime() - (hours - i) * 60 * 60 * 1000);
          await storage.insertWeatherData({
            temperature: item.temperature,
            humidity: item.humidity,
            pressure: item.pressure,
            windSpeed: item.windSpeed,
            windDirection: item.windDirection,
            rainfall: item.rainfall || 0,
            uvIndex: item.uvIndex || 0,
          }, timestamp);
        }
        data = await storage.getWeatherDataByTimeRange(startTime, endTime);
      }

      res.json(data);
    } catch (error) {
      console.error("Error getting historical weather:", error);
      res.status(500).json({ error: "Failed to fetch historical weather data" });
    }
  });

  // Get all alerts
  app.get("/api/alerts", async (_req, res) => {
    try {
      const alerts = await storage.getAllAlerts();
      res.json(alerts);
    } catch (error) {
      console.error("Error getting alerts:", error);
      res.status(500).json({ error: "Failed to fetch alerts" });
    }
  });

  // Create alert
  app.post("/api/alerts", async (req, res) => {
    try {
      const validated = insertAlertSchema.parse(req.body);
      const alert = await storage.createAlert(validated);
      res.json(alert);
    } catch (error) {
      console.error("Error creating alert:", error);
      res.status(400).json({ error: "Invalid alert data" });
    }
  });

  // Update alert
  app.patch("/api/alerts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const alert = await storage.updateAlert(id, req.body);
      
      if (!alert) {
        return res.status(404).json({ error: "Alert not found" });
      }
      
      res.json(alert);
    } catch (error) {
      console.error("Error updating alert:", error);
      res.status(500).json({ error: "Failed to update alert" });
    }
  });

  // Delete alert
  app.delete("/api/alerts/:id", async (req, res) => {
    try {
      const { id } = req.params;
      const deleted = await storage.deleteAlert(id);
      
      if (!deleted) {
        return res.status(404).json({ error: "Alert not found" });
      }
      
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting alert:", error);
      res.status(500).json({ error: "Failed to delete alert" });
    }
  });

  // Get user settings
  app.get("/api/settings", async (_req, res) => {
    try {
      const settings = await storage.getUserSettings();
      res.json(settings || {});
    } catch (error) {
      console.error("Error getting settings:", error);
      res.status(500).json({ error: "Failed to fetch settings" });
    }
  });

  // Update user settings
  app.patch("/api/settings", async (req, res) => {
    try {
      const settings = await storage.updateUserSettings(req.body);
      res.json(settings);
    } catch (error) {
      console.error("Error updating settings:", error);
      res.status(500).json({ error: "Failed to update settings" });
    }
  });

  // Export data as CSV
  app.get("/api/export/csv", async (req, res) => {
    try {
      const hours = parseInt(req.query.hours as string) || 24;
      const endTime = new Date();
      const startTime = new Date(endTime.getTime() - hours * 60 * 60 * 1000);

      const data = await storage.getWeatherDataByTimeRange(startTime, endTime);

      const csv = [
        "Timestamp,Temperature,Humidity,Pressure,Wind Speed,Wind Direction,Rainfall,UV Index",
        ...data.map((item) =>
          [
            new Date(item.timestamp).toISOString(),
            item.temperature,
            item.humidity,
            item.pressure,
            item.windSpeed,
            item.windDirection,
            item.rainfall,
            item.uvIndex,
          ].join(",")
        ),
      ].join("\n");

      res.header("Content-Type", "text/csv");
      res.header("Content-Disposition", `attachment; filename="weather-data-${new Date().toISOString()}.csv"`);
      res.send(csv);
    } catch (error) {
      console.error("Error exporting CSV:", error);
      res.status(500).json({ error: "Failed to export data" });
    }
  });

  // Export data as JSON
  app.get("/api/export/json", async (req, res) => {
    try {
      const hours = parseInt(req.query.hours as string) || 24;
      const endTime = new Date();
      const startTime = new Date(endTime.getTime() - hours * 60 * 60 * 1000);

      const data = await storage.getWeatherDataByTimeRange(startTime, endTime);

      res.header("Content-Type", "application/json");
      res.header("Content-Disposition", `attachment; filename="weather-data-${new Date().toISOString()}.json"`);
      res.json(data);
    } catch (error) {
      console.error("Error exporting JSON:", error);
      res.status(500).json({ error: "Failed to export data" });
    }
  });

  // Start automatic data fetching
  const settings = await storage.getUserSettings();
  const intervalMinutes = settings?.updateInterval || 180;
  
  // Initial fetch
  await fetchAndStoreWeatherData();
  
  // Set up interval
  if (updateInterval) {
    clearInterval(updateInterval);
  }
  updateInterval = setInterval(fetchAndStoreWeatherData, intervalMinutes * 60 * 1000);
  console.log(`Weather data update interval set to ${intervalMinutes} minutes`);

  const httpServer = createServer(app);

  return httpServer;
}
