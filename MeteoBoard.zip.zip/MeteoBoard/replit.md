# Stazione Meteo - Dashboard Tempo Reale

Un'applicazione web moderna e professionale per visualizzare i dati meteo in tempo reale da una stazione meteorologica ThingsBoard.

## Panoramica

Questo progetto fornisce una dashboard interattiva per monitorare le condizioni meteo con:
- Visualizzazione in tempo reale di temperatura, umidità, pressione e vento
- Grafici interattivi animati per l'andamento storico (24 ore e 7 giorni)
- Sistema di allerte configurabili
- Personalizzazione completa (unità di misura, tema, lingua)
- Esportazione dati in CSV/JSON
- Design responsive per tutti i dispositivi

## Architettura

### Frontend
- **React** con TypeScript per l'interfaccia utente
- **TanStack Query** per la gestione dello state e data fetching
- **Recharts** per grafici interattivi
- **Tailwind CSS** + **shadcn/ui** per lo styling
- **Wouter** per il routing
- **Context API** per la gestione delle impostazioni globali

### Backend
- **Express.js** server per le API
- **Axios** per l'integrazione con ThingsBoard
- **In-memory storage** per dati e configurazioni
- **Auto-polling** configurabile per aggiornamenti automatici

### Integrazione ThingsBoard
Il backend si connette al server ThingsBoard tramite API REST per recuperare:
- Dati telemetria in tempo reale
- Dati storici per i grafici
- Supporto per sensori multipli

## Struttura File

```
├── client/
│   ├── src/
│   │   ├── components/          # Componenti React riutilizzabili
│   │   │   ├── CurrentConditions.tsx    # Card hero con condizioni attuali
│   │   │   ├── MetricCard.tsx          # Card metrica singola
│   │   │   ├── WeatherChart.tsx        # Grafici interattivi
│   │   │   ├── AlertsPanel.tsx         # Gestione allerte
│   │   │   ├── SettingsDialog.tsx      # Pannello impostazioni
│   │   │   ├── ExportDialog.tsx        # Dialog esportazione dati
│   │   │   ├── Header.tsx              # Header navigazione
│   │   │   └── WeatherIcon.tsx         # Icone meteo dinamiche
│   │   ├── contexts/
│   │   │   └── SettingsContext.tsx     # Context per impostazioni globali
│   │   ├── lib/
│   │   │   ├── translations.ts         # Sistema i18n (IT/EN)
│   │   │   └── weatherUtils.ts         # Utility per conversioni
│   │   ├── pages/
│   │   │   └── Dashboard.tsx           # Pagina principale dashboard
│   │   └── App.tsx                     # App root con providers
├── server/
│   ├── routes.ts                # API endpoints
│   ├── storage.ts               # Interface storage dati
│   ├── thingsboard.ts           # Client ThingsBoard
│   └── weatherUtils.ts          # Utility server-side
└── shared/
    └── schema.ts                # Schemi dati condivisi

```

## API Endpoints

### Weather Data
- `GET /api/weather/current` - Dati meteo correnti
- `GET /api/weather/historical?hours=168` - Dati storici (default 7 giorni)

### Alerts
- `GET /api/alerts` - Tutte le allerte
- `POST /api/alerts` - Crea nuova allerta
- `PATCH /api/alerts/:id` - Aggiorna allerta
- `DELETE /api/alerts/:id` - Elimina allerta

### Settings
- `GET /api/settings` - Impostazioni utente
- `PATCH /api/settings` - Aggiorna impostazioni

### Export
- `GET /api/export/csv?hours=24` - Esporta dati in CSV
- `GET /api/export/json?hours=24` - Esporta dati in JSON

## Configurazione ThingsBoard

L'applicazione richiede tre variabili d'ambiente per connettersi a ThingsBoard:

- `THINGSBOARD_URL`: URL del server (es: https://demo.thingsboard.io)
- `THINGSBOARD_TOKEN`: Token JWT per autenticazione
- `THINGSBOARD_DEVICE_ID`: ID del dispositivo sensore

Se non configurate, l'app genererà dati mock per demo.

## Features Implementate

### MVP (Completato ✅)
✅ Dashboard moderna con visualizzazione tempo reale  
✅ Integrazione ThingsBoard con auto-polling  
✅ Grafici interattivi 24h/7giorni con timestamp corretti  
✅ Sistema allerte configurabili  
✅ Design responsive (mobile/tablet/desktop)  
✅ Personalizzazione (°C/°F, km/h/mph, hPa/inHg, mm/inches)  
✅ Tema chiaro/scuro persistente  
✅ Multilingua (Italiano/Inglese)  
✅ Esportazione dati CSV/JSON  
✅ Gestione errori connessione  
✅ Copertura completa data-testid per automation  
✅ Test e2e validati (tutti i flussi critici)  

### Funzionalità Chiave

**Condizioni Correnti**
- Temperatura con gradiente colore dinamico
- Temperatura percepita calcolata
- Icona meteo basata su condizioni
- Metriche rapide (umidità, vento)

**Grafici Storici**
- Andamento 24 ore (temperatura, umidità)
- Andamento 7 giorni
- Animazioni fluide
- Tooltip interattivi

**Sistema Allerte**
- Soglie configurabili per ogni metrica
- Condizioni "sopra/sotto"
- Enable/disable individuali
- Messaggi personalizzabili

**Personalizzazione**
- Unità di misura per ogni grandezza
- Tema light/dark con persistenza
- Lingua interface (IT/EN)
- Intervallo aggiornamento configurabile
- Nome e posizione stazione

**Esportazione**
- Range temporale selezionabile
- Formato CSV o JSON
- Download immediato

## Design System

L'applicazione segue le design guidelines in `design_guidelines.md`:
- Colori specifici per meteo (temperatura calda/fredda, umidità, vento, pressione)
- Typography: Inter (UI), JetBrains Mono (numeri), Poppins (headings)
- Spacing consistente (4, 6, 8, 12, 16, 20, 24px)
- Responsive breakpoints: Mobile (<768px), Tablet (768-1024px), Desktop (>1024px)
- Animazioni sottili e fluide

## Sviluppo

```bash
# Installa dipendenze
npm install

# Avvia development server
npm run dev

# Build production
npm run build

# Avvia production
npm start
```

L'app sarà disponibile su http://localhost:5000

## Note Tecniche

- I dati vengono aggiornati automaticamente ogni N minuti (configurabile)
- Storage in-memory - i dati persistono durante l'esecuzione
- Conserva automaticamente ultimi 30 giorni di dati
- Timestamp preservati correttamente per dati storici (fix critico implementato)
- Copertura completa data-testid per testing automatizzato
- Supporto completo keyboard navigation
- WCAG AA contrast ratios
- Ottimizzato per performance con React Query caching
- Test e2e validati con successo (Playwright)

## Prossime Features (Roadmap)

- Integrazione API previsioni esterne (OpenWeatherMap)
- Mappa interattiva con radar precipitazioni
- Notifiche push/email per allerte critiche
- Analisi avanzata con statistiche mensili/annuali
- Widget personalizzabili con dashboard modulare
