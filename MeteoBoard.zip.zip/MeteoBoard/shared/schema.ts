import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, real, integer, boolean, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Weather data from ThingsBoard sensor
export const weatherData = pgTable("weather_data", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  timestamp: timestamp("timestamp").notNull().defaultNow(),
  temperature: real("temperature").notNull(), // Celsius
  humidity: real("humidity").notNull(), // %
  pressure: real("pressure").notNull(), // hPa
  windSpeed: real("wind_speed").notNull(), // km/h
  windDirection: integer("wind_direction").notNull(), // degrees 0-360
  rainfall: real("rainfall").default(0), // mm
  uvIndex: real("uv_index").default(0),
});

// User alert configurations
export const alerts = pgTable("alerts", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: text("type").notNull(), // temperature, wind, pressure, etc.
  condition: text("condition").notNull(), // above, below
  threshold: real("threshold").notNull(),
  message: text("message").notNull(),
  enabled: boolean("enabled").notNull().default(true),
  createdAt: timestamp("created_at").notNull().defaultNow(),
});

// User settings for personalization
export const userSettings = pgTable("user_settings", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  temperatureUnit: text("temperature_unit").notNull().default("celsius"), // celsius, fahrenheit
  speedUnit: text("speed_unit").notNull().default("kmh"), // kmh, mph
  pressureUnit: text("pressure_unit").notNull().default("hpa"), // hpa, inHg
  precipitationUnit: text("precipitation_unit").notNull().default("mm"), // mm, inches
  theme: text("theme").notNull().default("dark"), // light, dark
  language: text("language").notNull().default("it"), // it, en
  updateInterval: integer("update_interval").notNull().default(180), // minutes
  stationName: text("station_name").default("Stazione Meteo"),
  stationLocation: text("station_location").default(""),
});

// Schemas for inserts
export const insertWeatherDataSchema = createInsertSchema(weatherData).omit({
  id: true,
  timestamp: true,
});

export const insertAlertSchema = createInsertSchema(alerts).omit({
  id: true,
  createdAt: true,
});

export const insertUserSettingsSchema = createInsertSchema(userSettings).omit({
  id: true,
});

// Types
export type WeatherData = typeof weatherData.$inferSelect;
export type InsertWeatherData = z.infer<typeof insertWeatherDataSchema>;

export type Alert = typeof alerts.$inferSelect;
export type InsertAlert = z.infer<typeof insertAlertSchema>;

export type UserSettings = typeof userSettings.$inferSelect;
export type InsertUserSettings = z.infer<typeof insertUserSettingsSchema>;

// Frontend types for UI state
export const weatherConditions = ["sunny", "cloudy", "rainy", "stormy", "snowy", "foggy"] as const;
export type WeatherCondition = typeof weatherConditions[number];

export interface TranslationStrings {
  // Navigation
  dashboard: string;
  charts: string;
  alerts: string;
  settings: string;
  export: string;
  
  // Current conditions
  currentConditions: string;
  temperature: string;
  feelsLike: string;
  humidity: string;
  pressure: string;
  wind: string;
  windSpeed: string;
  windDirection: string;
  rainfall: string;
  uvIndex: string;
  
  // Time
  lastUpdate: string;
  hourlyForecast: string;
  weeklyForecast: string;
  hour: string;
  day: string;
  
  // Alerts
  activeAlerts: string;
  noAlerts: string;
  createAlert: string;
  alertType: string;
  condition: string;
  threshold: string;
  message: string;
  enabled: string;
  
  // Settings
  units: string;
  appearance: string;
  general: string;
  temperatureUnit: string;
  speedUnit: string;
  pressureUnit: string;
  precipitationUnit: string;
  darkMode: string;
  lightMode: string;
  language: string;
  updateInterval: string;
  stationName: string;
  stationLocation: string;
  
  // Export
  exportData: string;
  exportCSV: string;
  exportJSON: string;
  selectDateRange: string;
  last24Hours: string;
  last7Days: string;
  last30Days: string;
  
  // Common
  save: string;
  cancel: string;
  delete: string;
  edit: string;
  close: string;
  loading: string;
  error: string;
  success: string;
  
  // Directions
  n: string;
  ne: string;
  e: string;
  se: string;
  s: string;
  sw: string;
  w: string;
  nw: string;
  
  // Error messages
  connectionError: string;
  dataLoadError: string;
  saveError: string;
}
