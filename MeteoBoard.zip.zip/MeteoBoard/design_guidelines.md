# Design Guidelines: Weather Station Data Visualization

## Design Approach

**Selected Approach**: Design System (Material Design 3) with Weather App Inspiration

**Justification**: This is a utility-focused, information-dense dashboard requiring clear data hierarchy, real-time updates, and optimal readability. Drawing from Material Design 3 for component consistency while incorporating visual patterns from modern weather applications (Weather.com, AccuWeather, Apple Weather).

**Core Principles**:
- Data clarity over decoration
- Immediate comprehension of current conditions
- Seamless real-time updates
- Professional meteorological aesthetic

---

## Color Palette

### Dark Mode (Primary)
- **Background**: 220 25% 10% (deep navy-blue)
- **Surface**: 220 20% 15% (elevated cards)
- **Surface Variant**: 220 15% 20% (sections)
- **Primary**: 200 100% 60% (bright sky blue)
- **Secondary**: 280 60% 65% (soft purple for alerts)
- **Success**: 140 60% 50% (weather conditions)
- **Warning**: 35 95% 60% (alerts)
- **Danger**: 0 80% 60% (severe weather)
- **Text Primary**: 0 0% 95%
- **Text Secondary**: 0 0% 70%

### Light Mode
- **Background**: 210 30% 98%
- **Surface**: 0 0% 100%
- **Primary**: 200 90% 45%
- **Text Primary**: 220 20% 15%

### Weather-Specific Colors
- **Temperature Hot**: 15 90% 55%
- **Temperature Cold**: 200 80% 50%
- **Humidity**: 180 60% 50%
- **Wind**: 160 50% 55%
- **Pressure**: 270 50% 60%

---

## Typography

**Font Families**:
- Primary: 'Inter' (Google Fonts) - UI text, labels
- Numeric: 'JetBrains Mono' (Google Fonts) - temperatures, measurements
- Accent: 'Poppins' (Google Fonts) - headings only

**Scale**:
- **Hero Numbers** (current temp): text-6xl/text-7xl, font-bold, JetBrains Mono
- **H1** (section titles): text-3xl, font-semibold, Poppins
- **H2** (card headers): text-xl, font-medium, Inter
- **Body**: text-base, font-normal, Inter
- **Labels**: text-sm, font-medium, Inter, uppercase tracking-wide
- **Small Data**: text-xs, font-normal, Inter

---

## Layout System

**Spacing Primitives**: Use Tailwind units of 2, 4, 6, 8, 12, 16, 20, 24

**Grid Structure**:
- **Container**: max-w-7xl mx-auto px-4 md:px-6 lg:px-8
- **Dashboard Grid**: 12-column responsive grid
- **Card Spacing**: gap-4 md:gap-6 lg:gap-8
- **Section Padding**: py-6 md:py-8 lg:py-12

**Breakpoints**:
- Mobile: < 768px (single column)
- Tablet: 768px - 1024px (2 columns)
- Desktop: > 1024px (3-4 columns)

---

## Component Library

### Dashboard Layout
**Header Navigation**:
- Fixed top bar with station name, location icon, settings
- Real-time update indicator (pulsing dot)
- Theme toggle, language selector, export button
- Height: h-16, backdrop blur with shadow

**Main Dashboard Grid**:
- **Hero Card** (full-width): Current conditions with large temperature display, weather icon, feels-like, description
- **Metrics Grid** (3-4 columns): Humidity, Wind Speed/Direction, Pressure, UV Index - each in individual cards
- **24-Hour Forecast** (full-width): Horizontal scrolling timeline with hourly temps and icons
- **7-Day Forecast** (full-width): Card grid showing daily highs/lows, conditions
- **Charts Section** (2-column): Historical temperature/humidity line charts
- **Alerts Banner**: Conditional display for weather warnings

### Cards
- **Base Style**: Rounded corners (rounded-xl), subtle shadow, backdrop-blur
- **Padding**: p-4 md:p-6
- **Border**: 1px border in surface-variant color
- **Hover**: Subtle lift effect (translate-y-1 transition)

### Weather Icons
Use **WeatherIcons** library or **Heroicons** for UI controls
- Large icons (w-16 h-16) for current conditions
- Medium (w-12 h-12) for forecasts
- Small (w-8 h-8) for hourly timeline

### Data Visualization
**Charts Library**: Chart.js via CDN
- Line charts: Temperature/humidity trends with gradient fills
- Wind rose: Circular direction indicator
- Pressure graph: Area chart with threshold markers
- Color-coded: Use weather-specific colors from palette

### Buttons & Controls
- **Primary Action**: bg-primary rounded-lg px-6 py-3 font-medium
- **Secondary**: border-2 border-primary rounded-lg px-6 py-3
- **Icon Buttons**: p-2 rounded-full hover:bg-surface-variant
- **Toggle Switches**: For theme, units, settings

### Input Fields
- **Dark backgrounds**: bg-surface-variant with lighter text
- **Labels**: Above input, text-sm font-medium
- **Borders**: Focus state with primary color ring
- **Dropdowns**: Custom styled selects matching theme

### Modals & Overlays
- **Settings Modal**: Center-aligned, max-w-2xl, with tabs for preferences
- **Data Export**: Simple modal with date range picker and format selection
- **Alert Details**: Slide-in panel from right with full alert information

---

## Animations

**Use Sparingly**:
- **Data Updates**: Smooth number transitions (1s ease-in-out)
- **Loading States**: Skeleton screens with subtle shimmer
- **Card Entrance**: Stagger effect on initial load (50ms delay between cards)
- **Live Indicator**: Gentle pulse on update dot
- **Chart Animations**: 800ms ease for line draws

**No animations for**: Scrolling, hover states (except subtle transforms), page transitions

---

## Images

**Hero/Current Conditions Background**:
- **Option 1**: Subtle gradient overlay matching current weather conditions (sunny=warm gradient, rainy=cool blues)
- **Option 2**: Blurred weather imagery as backdrop with data overlaid
- **Placement**: Top hero card only, not throughout dashboard

**Weather Condition Icons**: Use icon library, not images

**Location**: No specific location images needed for data dashboard

---

## Accessibility

- WCAG AA contrast ratios maintained in both modes
- Keyboard navigation: Tab through all interactive elements
- Screen reader labels for all data points
- Focus indicators: 2px ring in primary color
- Skip to main content link
- Aria-live regions for real-time data updates

---

## Unique Features

**Real-time Updates**: Visual indicator showing last update timestamp and auto-refresh countdown

**Customization Panel**: Floating settings FAB (bottom-right) for quick access to units, theme, language without leaving dashboard

**Data Export**: One-click export with pre-configured common ranges (Last 24h, Last Week, Last Month)

**Responsive Wind Rose**: Interactive circular diagram showing wind direction distribution

**Temperature Gradient**: Background subtle gradient shift based on current temperature (cooler=blue tones, warmer=orange tones)