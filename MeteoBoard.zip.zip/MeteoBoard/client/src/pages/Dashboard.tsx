import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { Header } from "@/components/Header";
import { CurrentConditions } from "@/components/CurrentConditions";
import { MetricCard } from "@/components/MetricCard";
import { WeatherChart } from "@/components/WeatherChart";
import { AlertsPanel } from "@/components/AlertsPanel";
import { Alert, WeatherData } from "@shared/schema";
import { useSettings } from "@/contexts/SettingsContext";
import { translations } from "@/lib/translations";
import {
  convertSpeed,
  convertPressure,
  convertPrecipitation,
  getWindDirection,
  generateMockHistoricalData,
} from "@/lib/weatherUtils";
import { Navigation, Droplets, Gauge, CloudRain, Sun } from "lucide-react";
import { Alert as AlertComponent } from "@/components/ui/alert";
import { AlertCircle } from "lucide-react";

export default function Dashboard() {
  const { settings } = useSettings();
  const t = translations[settings.language];
  const [alerts, setAlerts] = useState<Alert[]>([]);

  // Fetch current weather data
  const { data: currentData, isLoading: currentLoading, error: currentError } = useQuery<WeatherData>({
    queryKey: ["/api/weather/current"],
    refetchInterval: settings.updateInterval * 60 * 1000,
  });

  // Fetch historical data for charts
  const { data: historicalData, isLoading: historicalLoading } = useQuery<WeatherData[]>({
    queryKey: ["/api/weather/historical"],
    refetchInterval: settings.updateInterval * 60 * 1000,
  });

  // Use mock data for demo
  const mockCurrent = generateMockHistoricalData(1)[0];
  const mockHistorical = generateMockHistoricalData(168); // 7 days

  const weatherData = currentData || mockCurrent;
  const chartData = historicalData || mockHistorical;

  // Check alerts
  useEffect(() => {
    if (!weatherData) return;

    const checkAlerts = () => {
      alerts.forEach((alert) => {
        if (!alert.enabled) return;

        let value: number = 0;
        switch (alert.type) {
          case "temperature":
            value = weatherData.temperature;
            break;
          case "humidity":
            value = weatherData.humidity;
            break;
          case "pressure":
            value = weatherData.pressure;
            break;
          case "windSpeed":
            value = weatherData.windSpeed;
            break;
        }

        const triggered =
          alert.condition === "above" ? value > alert.threshold : value < alert.threshold;

        if (triggered) {
          // Show notification (simplified)
          console.log(`Alert triggered: ${alert.message}`);
        }
      });
    };

    checkAlerts();
  }, [weatherData, alerts]);

  const handleCreateAlert = (alert: Omit<Alert, "id" | "createdAt">) => {
    const newAlert: Alert = {
      ...alert,
      id: `alert-${Date.now()}`,
      createdAt: new Date(),
    };
    setAlerts([...alerts, newAlert]);
  };

  const handleDeleteAlert = (id: string) => {
    setAlerts(alerts.filter((a) => a.id !== id));
  };

  const handleToggleAlert = (id: string, enabled: boolean) => {
    setAlerts(alerts.map((a) => (a.id === id ? { ...a, enabled } : a)));
  };

  if (currentError) {
    return (
      <div className="min-h-screen bg-background">
        <Header weatherData={chartData} />
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-8">
          <AlertComponent variant="destructive">
            <AlertCircle className="h-4 w-4" />
            <div>
              <h3 className="font-semibold">{t.error}</h3>
              <p>{t.connectionError}</p>
            </div>
          </AlertComponent>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Header weatherData={chartData} lastUpdate={weatherData?.timestamp ? new Date(weatherData.timestamp) : undefined} />

      <main className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8 py-6 md:py-8">
        {/* Hero - Current Conditions */}
        <div className="mb-6 md:mb-8">
          <CurrentConditions data={weatherData} loading={currentLoading} />
        </div>

        {/* Metrics Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 md:gap-6 mb-6 md:mb-8">
          <MetricCard
            title={t.humidity}
            value={weatherData?.humidity || 0}
            unit="%"
            icon="humidity"
            color="hsl(180 60% 50%)"
            loading={currentLoading}
            testId="card-humidity"
          />
          <MetricCard
            title={t.pressure}
            value={
              weatherData
                ? convertPressure(weatherData.pressure, settings.pressureUnit)
                : 0
            }
            unit={settings.pressureUnit}
            icon="pressure"
            color="hsl(270 50% 60%)"
            loading={currentLoading}
            testId="card-pressure"
          />
          <MetricCard
            title={t.windSpeed}
            value={
              weatherData ? convertSpeed(weatherData.windSpeed, settings.speedUnit) : 0
            }
            unit={settings.speedUnit}
            subtitle={
              weatherData
                ? `${t.windDirection}: ${getWindDirection(weatherData.windDirection)}`
                : undefined
            }
            IconComponent={Navigation}
            color="hsl(160 50% 55%)"
            loading={currentLoading}
            testId="card-wind"
          />
          <MetricCard
            title={t.rainfall}
            value={
              weatherData
                ? convertPrecipitation(weatherData.rainfall || 0, settings.precipitationUnit)
                : 0
            }
            unit={settings.precipitationUnit}
            icon="rainfall"
            color="hsl(200 80% 50%)"
            loading={currentLoading}
            testId="card-rainfall"
          />
        </div>

        {/* Charts Section */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 mb-6 md:mb-8">
          <WeatherChart
            data={chartData.slice(-24)}
            type="hourly"
            metric="temperature"
            loading={historicalLoading}
          />
          <WeatherChart
            data={chartData.slice(-24)}
            type="hourly"
            metric="humidity"
            loading={historicalLoading}
          />
        </div>

        <div className="mb-6 md:mb-8">
          <WeatherChart
            data={chartData.filter((_, i) => i % 24 === 0).slice(-7)}
            type="daily"
            metric="temperature"
            loading={historicalLoading}
          />
        </div>

        {/* Alerts Panel */}
        <div>
          <AlertsPanel
            alerts={alerts}
            onCreateAlert={handleCreateAlert}
            onDeleteAlert={handleDeleteAlert}
            onToggleAlert={handleToggleAlert}
          />
        </div>
      </main>
    </div>
  );
}
