import { TranslationStrings } from "@shared/schema";

export const translations: Record<"it" | "en", TranslationStrings> = {
  it: {
    // Navigation
    dashboard: "Dashboard",
    charts: "Grafici",
    alerts: "Allerte",
    settings: "Impostazioni",
    export: "Esporta",
    
    // Current conditions
    currentConditions: "Condizioni Attuali",
    temperature: "Temperatura",
    feelsLike: "Percepita",
    humidity: "Umidità",
    pressure: "Pressione",
    wind: "Vento",
    windSpeed: "Velocità Vento",
    windDirection: "Direzione Vento",
    rainfall: "Precipitazioni",
    uvIndex: "Indice UV",
    
    // Time
    lastUpdate: "Ultimo aggiornamento",
    hourlyForecast: "Andamento 24 Ore",
    weeklyForecast: "Andamento 7 Giorni",
    hour: "ora",
    day: "giorno",
    
    // Alerts
    activeAlerts: "Allerte Attive",
    noAlerts: "Nessuna allerta attiva",
    createAlert: "Crea Allerta",
    alertType: "Tipo",
    condition: "Condizione",
    threshold: "Soglia",
    message: "Messaggio",
    enabled: "Attivo",
    
    // Settings
    units: "Unità di Misura",
    appearance: "Aspetto",
    general: "Generale",
    temperatureUnit: "Temperatura",
    speedUnit: "Velocità",
    pressureUnit: "Pressione",
    precipitationUnit: "Precipitazioni",
    darkMode: "Scuro",
    lightMode: "Chiaro",
    language: "Lingua",
    updateInterval: "Intervallo Aggiornamento",
    stationName: "Nome Stazione",
    stationLocation: "Posizione",
    
    // Export
    exportData: "Esporta Dati",
    exportCSV: "Esporta CSV",
    exportJSON: "Esporta JSON",
    selectDateRange: "Seleziona Periodo",
    last24Hours: "Ultime 24 Ore",
    last7Days: "Ultimi 7 Giorni",
    last30Days: "Ultimi 30 Giorni",
    
    // Common
    save: "Salva",
    cancel: "Annulla",
    delete: "Elimina",
    edit: "Modifica",
    close: "Chiudi",
    loading: "Caricamento...",
    error: "Errore",
    success: "Successo",
    
    // Directions
    n: "N",
    ne: "NE",
    e: "E",
    se: "SE",
    s: "S",
    sw: "SO",
    w: "O",
    nw: "NO",
    
    // Error messages
    connectionError: "Errore di connessione con il sensore",
    dataLoadError: "Impossibile caricare i dati",
    saveError: "Errore durante il salvataggio",
  },
  en: {
    // Navigation
    dashboard: "Dashboard",
    charts: "Charts",
    alerts: "Alerts",
    settings: "Settings",
    export: "Export",
    
    // Current conditions
    currentConditions: "Current Conditions",
    temperature: "Temperature",
    feelsLike: "Feels Like",
    humidity: "Humidity",
    pressure: "Pressure",
    wind: "Wind",
    windSpeed: "Wind Speed",
    windDirection: "Wind Direction",
    rainfall: "Rainfall",
    uvIndex: "UV Index",
    
    // Time
    lastUpdate: "Last update",
    hourlyForecast: "24 Hour Trend",
    weeklyForecast: "7 Day Trend",
    hour: "hour",
    day: "day",
    
    // Alerts
    activeAlerts: "Active Alerts",
    noAlerts: "No active alerts",
    createAlert: "Create Alert",
    alertType: "Type",
    condition: "Condition",
    threshold: "Threshold",
    message: "Message",
    enabled: "Enabled",
    
    // Settings
    units: "Units",
    appearance: "Appearance",
    general: "General",
    temperatureUnit: "Temperature",
    speedUnit: "Speed",
    pressureUnit: "Pressure",
    precipitationUnit: "Precipitation",
    darkMode: "Dark",
    lightMode: "Light",
    language: "Language",
    updateInterval: "Update Interval",
    stationName: "Station Name",
    stationLocation: "Location",
    
    // Export
    exportData: "Export Data",
    exportCSV: "Export CSV",
    exportJSON: "Export JSON",
    selectDateRange: "Select Period",
    last24Hours: "Last 24 Hours",
    last7Days: "Last 7 Days",
    last30Days: "Last 30 Days",
    
    // Common
    save: "Save",
    cancel: "Cancel",
    delete: "Delete",
    edit: "Edit",
    close: "Close",
    loading: "Loading...",
    error: "Error",
    success: "Success",
    
    // Directions
    n: "N",
    ne: "NE",
    e: "E",
    se: "SE",
    s: "S",
    sw: "SW",
    w: "W",
    nw: "NW",
    
    // Error messages
    connectionError: "Sensor connection error",
    dataLoadError: "Unable to load data",
    saveError: "Error saving",
  },
};
