import { WeatherCondition, WeatherData } from "@shared/schema";

// Convert temperature between units
export function convertTemperature(celsius: number, unit: "celsius" | "fahrenheit"): number {
  return unit === "fahrenheit" ? (celsius * 9) / 5 + 32 : celsius;
}

// Convert wind speed between units
export function convertSpeed(kmh: number, unit: "kmh" | "mph"): number {
  return unit === "mph" ? kmh * 0.621371 : kmh;
}

// Convert pressure between units
export function convertPressure(hpa: number, unit: "hpa" | "inHg"): number {
  return unit === "inHg" ? hpa * 0.02953 : hpa;
}

// Convert precipitation between units
export function convertPrecipitation(mm: number, unit: "mm" | "inches"): number {
  return unit === "inches" ? mm * 0.0393701 : mm;
}

// Get wind direction from degrees
export function getWindDirection(degrees: number): string {
  const directions = ["N", "NE", "E", "SE", "S", "SW", "W", "NW"];
  const index = Math.round(((degrees % 360) / 45)) % 8;
  return directions[index];
}

// Determine weather condition from data
export function getWeatherCondition(data: WeatherData): WeatherCondition {
  if (data.rainfall > 5) return "rainy";
  if (data.rainfall > 0.5) return "cloudy";
  if (data.temperature < 0) return "snowy";
  if (data.windSpeed > 50) return "stormy";
  if (data.humidity < 30) return "sunny";
  if (data.humidity > 85) return "foggy";
  return "cloudy";
}

// Calculate feels like temperature (wind chill / heat index)
export function calculateFeelsLike(temp: number, humidity: number, windSpeed: number): number {
  if (temp < 10 && windSpeed > 5) {
    // Wind chill
    const windKph = windSpeed;
    const windChill =
      13.12 +
      0.6215 * temp -
      11.37 * Math.pow(windKph, 0.16) +
      0.3965 * temp * Math.pow(windKph, 0.16);
    return windChill;
  } else if (temp > 27) {
    // Heat index
    const hi =
      -8.78469475556 +
      1.61139411 * temp +
      2.33854883889 * humidity +
      -0.14611605 * temp * humidity +
      -0.012308094 * temp * temp +
      -0.0164248277778 * humidity * humidity +
      0.002211732 * temp * temp * humidity +
      0.00072546 * temp * humidity * humidity +
      -0.000003582 * temp * temp * humidity * humidity;
    return hi;
  }
  return temp;
}

// Format time for charts
export function formatTime(date: Date): string {
  return date.toLocaleTimeString("it-IT", { hour: "2-digit", minute: "2-digit" });
}

// Format date for charts
export function formatDate(date: Date, locale: "it" | "en" = "it"): string {
  return date.toLocaleDateString(locale === "it" ? "it-IT" : "en-US", {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
}

// Get temperature color based on value
export function getTemperatureColor(temp: number): string {
  if (temp >= 30) return "hsl(15 90% 55%)";
  if (temp >= 20) return "hsl(35 85% 55%)";
  if (temp >= 10) return "hsl(50 75% 55%)";
  if (temp >= 0) return "hsl(200 70% 55%)";
  return "hsl(200 80% 50%)";
}

// Generate mock historical data for demo
export function generateMockHistoricalData(hours: number): WeatherData[] {
  const now = new Date();
  const data: WeatherData[] = [];
  
  for (let i = hours - 1; i >= 0; i--) {
    const timestamp = new Date(now.getTime() - i * 60 * 60 * 1000);
    const hour = timestamp.getHours();
    
    // Create realistic daily temperature pattern
    const baseTemp = 18;
    const tempVariation = 8 * Math.sin((hour - 6) * Math.PI / 12);
    const temp = baseTemp + tempVariation + (Math.random() - 0.5) * 2;
    
    data.push({
      id: `mock-${i}`,
      timestamp,
      temperature: parseFloat(temp.toFixed(1)),
      humidity: 55 + Math.random() * 30,
      pressure: 1013 + (Math.random() - 0.5) * 20,
      windSpeed: 10 + Math.random() * 20,
      windDirection: Math.floor(Math.random() * 360),
      rainfall: Math.random() > 0.8 ? Math.random() * 5 : 0,
      uvIndex: hour >= 6 && hour <= 18 ? Math.max(0, 8 - Math.abs(hour - 12)) : 0,
    });
  }
  
  return data;
}
