import { createContext, useContext, useState, useEffect, ReactNode } from "react";
import { UserSettings } from "@shared/schema";

interface SettingsContextType {
  settings: UserSettings;
  updateSettings: (settings: Partial<UserSettings>) => void;
  t: (key: string) => string;
}

const defaultSettings: UserSettings = {
  id: "default",
  temperatureUnit: "celsius",
  speedUnit: "kmh",
  pressureUnit: "hpa",
  precipitationUnit: "mm",
  theme: "dark",
  language: "it",
  updateInterval: 180,
  stationName: "Stazione Meteo",
  stationLocation: "",
};

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<UserSettings>(() => {
    const saved = localStorage.getItem("weatherStationSettings");
    return saved ? { ...defaultSettings, ...JSON.parse(saved) } : defaultSettings;
  });

  useEffect(() => {
    localStorage.setItem("weatherStationSettings", JSON.stringify(settings));
    
    // Apply theme
    if (settings.theme === "dark") {
      document.documentElement.classList.add("dark");
    } else {
      document.documentElement.classList.remove("dark");
    }
  }, [settings]);

  const updateSettings = (newSettings: Partial<UserSettings>) => {
    setSettings((prev) => ({ ...prev, ...newSettings }));
  };

  // Simple translation function (will be replaced with full i18n if needed)
  const t = (key: string) => key;

  return (
    <SettingsContext.Provider value={{ settings, updateSettings, t }}>
      {children}
    </SettingsContext.Provider>
  );
}

export function useSettings() {
  const context = useContext(SettingsContext);
  if (!context) {
    throw new Error("useSettings must be used within SettingsProvider");
  }
  return context;
}
