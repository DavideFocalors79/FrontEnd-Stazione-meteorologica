import { Card } from "@/components/ui/card";
import { WeatherIcon } from "./WeatherIcon";
import { WeatherData } from "@shared/schema";
import { useSettings } from "@/contexts/SettingsContext";
import {
  convertTemperature,
  getWeatherCondition,
  calculateFeelsLike,
  getTemperatureColor,
} from "@/lib/weatherUtils";
import { translations } from "@/lib/translations";

interface CurrentConditionsProps {
  data: WeatherData | null;
  loading?: boolean;
}

export function CurrentConditions({ data, loading }: CurrentConditionsProps) {
  const { settings } = useSettings();
  const t = translations[settings.language];

  if (loading || !data) {
    return (
      <Card className="p-6 md:p-8 lg:p-12">
        <div className="animate-pulse">
          <div className="h-8 bg-muted rounded w-48 mb-8"></div>
          <div className="flex items-center gap-8">
            <div className="h-32 w-32 bg-muted rounded-full"></div>
            <div className="h-24 bg-muted rounded w-64"></div>
          </div>
        </div>
      </Card>
    );
  }

  const condition = getWeatherCondition(data);
  const temp = convertTemperature(data.temperature, settings.temperatureUnit);
  const feelsLike = convertTemperature(
    calculateFeelsLike(data.temperature, data.humidity, data.windSpeed),
    settings.temperatureUnit
  );
  const tempColor = getTemperatureColor(data.temperature);
  const unit = settings.temperatureUnit === "celsius" ? "°C" : "°F";

  return (
    <Card className="p-6 md:p-8 lg:p-12 overflow-hidden relative" data-testid="card-current-conditions">
      {/* Subtle gradient background based on temperature */}
      <div 
        className="absolute inset-0 opacity-5 pointer-events-none"
        style={{
          background: `radial-gradient(circle at 30% 30%, ${tempColor}, transparent 70%)`,
        }}
      />
      
      <div className="relative">
        <h2 className="text-xl md:text-2xl font-semibold mb-6 md:mb-8 text-foreground">
          {t.currentConditions}
        </h2>
        
        <div className="flex flex-col md:flex-row items-start md:items-center gap-6 md:gap-12">
          {/* Weather icon */}
          <div className="flex-shrink-0">
            <WeatherIcon
              condition={condition}
              size={96}
              className="text-primary"
            />
          </div>

          {/* Temperature display */}
          <div className="flex-1">
            <div className="flex items-baseline gap-2 mb-2">
              <span 
                className="text-6xl md:text-7xl lg:text-8xl font-bold font-mono"
                style={{ color: tempColor }}
                data-testid="text-current-temperature"
              >
                {Math.round(temp)}
              </span>
              <span className="text-4xl md:text-5xl font-medium text-muted-foreground">
                {unit}
              </span>
            </div>
            
            <div className="flex items-center gap-4 text-sm md:text-base text-muted-foreground">
              <span data-testid="text-feels-like">
                {t.feelsLike}: <span className="font-medium text-foreground">{Math.round(feelsLike)}{unit}</span>
              </span>
              <span className="text-border">•</span>
              <span className="capitalize" data-testid="text-weather-condition">{condition}</span>
            </div>
          </div>

          {/* Additional quick stats */}
          <div className="grid grid-cols-2 gap-4 md:gap-6 text-sm md:text-base">
            <div>
              <div className="text-muted-foreground text-xs uppercase tracking-wide mb-1">
                {t.humidity}
              </div>
              <div className="font-semibold font-mono text-lg" data-testid="text-current-humidity">
                {Math.round(data.humidity)}%
              </div>
            </div>
            <div>
              <div className="text-muted-foreground text-xs uppercase tracking-wide mb-1">
                {t.windSpeed}
              </div>
              <div className="font-semibold font-mono text-lg" data-testid="text-current-wind">
                {Math.round(data.windSpeed)} {settings.speedUnit}
              </div>
            </div>
          </div>
        </div>
      </div>
    </Card>
  );
}
