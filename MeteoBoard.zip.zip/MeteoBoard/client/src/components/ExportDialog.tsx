import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Download } from "lucide-react";
import { WeatherData } from "@shared/schema";
import { useSettings } from "@/contexts/SettingsContext";
import { translations } from "@/lib/translations";
import { useToast } from "@/hooks/use-toast";

interface ExportDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  data: WeatherData[];
}

export function ExportDialog({ open, onOpenChange, data }: ExportDialogProps) {
  const { settings } = useSettings();
  const t = translations[settings.language];
  const { toast } = useToast();
  const [format, setFormat] = useState<"csv" | "json">("csv");
  const [range, setRange] = useState<"24h" | "7d" | "30d">("24h");

  const filterDataByRange = () => {
    const now = new Date();
    const hours = range === "24h" ? 24 : range === "7d" ? 168 : 720;
    const cutoff = new Date(now.getTime() - hours * 60 * 60 * 1000);
    return data.filter((item) => new Date(item.timestamp) >= cutoff);
  };

  const exportCSV = () => {
    const filteredData = filterDataByRange();
    const headers = ["Timestamp", "Temperature", "Humidity", "Pressure", "Wind Speed", "Wind Direction", "Rainfall", "UV Index"];
    const rows = filteredData.map((item) => [
      new Date(item.timestamp).toISOString(),
      item.temperature,
      item.humidity,
      item.pressure,
      item.windSpeed,
      item.windDirection,
      item.rainfall,
      item.uvIndex,
    ]);

    const csv = [headers, ...rows].map((row) => row.join(",")).join("\n");
    const blob = new Blob([csv], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `weather-data-${range}-${new Date().toISOString().split("T")[0]}.csv`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: t.success,
      description: "Dati esportati con successo",
    });
    onOpenChange(false);
  };

  const exportJSON = () => {
    const filteredData = filterDataByRange();
    const json = JSON.stringify(filteredData, null, 2);
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `weather-data-${range}-${new Date().toISOString().split("T")[0]}.json`;
    a.click();
    URL.revokeObjectURL(url);

    toast({
      title: t.success,
      description: "Dati esportati con successo",
    });
    onOpenChange(false);
  };

  const handleExport = () => {
    if (format === "csv") {
      exportCSV();
    } else {
      exportJSON();
    }
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{t.exportData}</DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label>Formato</Label>
            <Select value={format} onValueChange={(value) => setFormat(value as "csv" | "json")}>
              <SelectTrigger data-testid="select-export-format">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="csv">CSV</SelectItem>
                <SelectItem value="json">JSON</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>{t.selectDateRange}</Label>
            <Select value={range} onValueChange={(value) => setRange(value as "24h" | "7d" | "30d")}>
              <SelectTrigger data-testid="select-export-range">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="24h">{t.last24Hours}</SelectItem>
                <SelectItem value="7d">{t.last7Days}</SelectItem>
                <SelectItem value="30d">{t.last30Days}</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="text-sm text-muted-foreground">
            {filterDataByRange().length} record saranno esportati
          </div>

          <Button onClick={handleExport} className="w-full" data-testid="button-export-confirm">
            <Download size={16} className="mr-2" />
            {format === "csv" ? t.exportCSV : t.exportJSON}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
