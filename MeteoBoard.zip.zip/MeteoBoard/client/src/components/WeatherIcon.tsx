import { 
  Cloud, 
  CloudRain, 
  CloudSnow, 
  CloudLightning, 
  Sun, 
  CloudFog,
  Wind,
  Droplets,
  Gauge,
  Navigation,
  TrendingUp,
  TrendingDown
} from "lucide-react";
import { WeatherCondition } from "@shared/schema";

interface WeatherIconProps {
  condition?: WeatherCondition;
  type?: "temperature" | "humidity" | "pressure" | "wind" | "rainfall";
  className?: string;
  size?: number;
}

export function WeatherIcon({ condition, type, className = "", size = 24 }: WeatherIconProps) {
  if (type) {
    switch (type) {
      case "temperature":
        return <TrendingUp className={className} size={size} />;
      case "humidity":
        return <Droplets className={className} size={size} />;
      case "pressure":
        return <Gauge className={className} size={size} />;
      case "wind":
        return <Wind className={className} size={size} />;
      case "rainfall":
        return <CloudRain className={className} size={size} />;
    }
  }

  if (condition) {
    switch (condition) {
      case "sunny":
        return <Sun className={className} size={size} />;
      case "cloudy":
        return <Cloud className={className} size={size} />;
      case "rainy":
        return <CloudRain className={className} size={size} />;
      case "stormy":
        return <CloudLightning className={className} size={size} />;
      case "snowy":
        return <CloudSnow className={className} size={size} />;
      case "foggy":
        return <CloudFog className={className} size={size} />;
    }
  }

  return <Cloud className={className} size={size} />;
}
