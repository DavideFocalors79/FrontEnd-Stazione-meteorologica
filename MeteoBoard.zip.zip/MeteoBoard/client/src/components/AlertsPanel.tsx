import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { AlertTriangle, Plus, Trash2 } from "lucide-react";
import { Alert } from "@shared/schema";
import { useSettings } from "@/contexts/SettingsContext";
import { translations } from "@/lib/translations";

interface AlertsPanelProps {
  alerts: Alert[];
  onCreateAlert: (alert: Omit<Alert, "id" | "createdAt">) => void;
  onDeleteAlert: (id: string) => void;
  onToggleAlert: (id: string, enabled: boolean) => void;
}

export function AlertsPanel({ alerts, onCreateAlert, onDeleteAlert, onToggleAlert }: AlertsPanelProps) {
  const { settings } = useSettings();
  const t = translations[settings.language];
  const [open, setOpen] = useState(false);
  const [newAlert, setNewAlert] = useState({
    type: "temperature",
    condition: "above",
    threshold: 30,
    message: "",
    enabled: true,
  });

  const handleCreate = () => {
    if (newAlert.message) {
      onCreateAlert(newAlert);
      setOpen(false);
      setNewAlert({
        type: "temperature",
        condition: "above",
        threshold: 30,
        message: "",
        enabled: true,
      });
    }
  };

  const activeAlerts = alerts.filter((a) => a.enabled);

  return (
    <Card className="p-4 md:p-6" data-testid="panel-alerts">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <AlertTriangle className="text-weather-warning" size={20} />
          <h3 className="text-lg font-semibold">{t.activeAlerts}</h3>
          {activeAlerts.length > 0 && (
            <Badge variant="secondary" data-testid="badge-alerts-count">{activeAlerts.length}</Badge>
          )}
        </div>
        
        <Dialog open={open} onOpenChange={setOpen}>
          <DialogTrigger asChild>
            <Button size="sm" data-testid="button-create-alert">
              <Plus size={16} className="mr-1" />
              {t.createAlert}
            </Button>
          </DialogTrigger>
          <DialogContent>
            <DialogHeader>
              <DialogTitle>{t.createAlert}</DialogTitle>
            </DialogHeader>
            
            <div className="space-y-4 py-4">
              <div className="space-y-2">
                <Label>{t.alertType}</Label>
                <Select
                  value={newAlert.type}
                  onValueChange={(value) => setNewAlert({ ...newAlert, type: value })}
                >
                  <SelectTrigger data-testid="select-alert-type">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="temperature">{t.temperature}</SelectItem>
                    <SelectItem value="humidity">{t.humidity}</SelectItem>
                    <SelectItem value="pressure">{t.pressure}</SelectItem>
                    <SelectItem value="windSpeed">{t.windSpeed}</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>{t.condition}</Label>
                <Select
                  value={newAlert.condition}
                  onValueChange={(value) => setNewAlert({ ...newAlert, condition: value })}
                >
                  <SelectTrigger data-testid="select-alert-condition">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="above">Sopra</SelectItem>
                    <SelectItem value="below">Sotto</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label>{t.threshold}</Label>
                <Input
                  type="number"
                  value={newAlert.threshold}
                  onChange={(e) => setNewAlert({ ...newAlert, threshold: parseFloat(e.target.value) })}
                  data-testid="input-alert-threshold"
                />
              </div>

              <div className="space-y-2">
                <Label>{t.message}</Label>
                <Input
                  value={newAlert.message}
                  onChange={(e) => setNewAlert({ ...newAlert, message: e.target.value })}
                  placeholder="Messaggio di allerta"
                  data-testid="input-alert-message"
                />
              </div>

              <Button onClick={handleCreate} className="w-full" data-testid="button-save-alert">
                {t.save}
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <div className="space-y-3">
        {alerts.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground" data-testid="text-no-alerts">
            {t.noAlerts}
          </div>
        ) : (
          alerts.map((alert) => (
            <div
              key={alert.id}
              className="flex items-center justify-between p-3 rounded-lg border border-border hover-elevate"
              data-testid={`alert-item-${alert.id}`}
            >
              <div className="flex-1">
                <div className="flex items-center gap-2 mb-1">
                  <span className="font-medium text-sm capitalize">{alert.type}</span>
                  <Badge variant={alert.enabled ? "default" : "secondary"} className="text-xs">
                    {alert.condition} {alert.threshold}
                  </Badge>
                </div>
                <p className="text-sm text-muted-foreground">{alert.message}</p>
              </div>

              <div className="flex items-center gap-2">
                <Switch
                  checked={alert.enabled}
                  onCheckedChange={(checked) => onToggleAlert(alert.id, checked)}
                  data-testid={`switch-alert-${alert.id}`}
                />
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => onDeleteAlert(alert.id)}
                  data-testid={`button-delete-alert-${alert.id}`}
                >
                  <Trash2 size={16} />
                </Button>
              </div>
            </div>
          ))
        )}
      </div>
    </Card>
  );
}
