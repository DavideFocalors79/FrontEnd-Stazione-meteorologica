import { Card } from "@/components/ui/card";
import { WeatherIcon } from "./WeatherIcon";
import { LucideIcon } from "lucide-react";

interface MetricCardProps {
  title: string;
  value: string | number;
  unit?: string;
  icon?: "temperature" | "humidity" | "pressure" | "wind" | "rainfall";
  IconComponent?: LucideIcon;
  subtitle?: string;
  color?: string;
  loading?: boolean;
  testId?: string;
}

export function MetricCard({
  title,
  value,
  unit,
  icon,
  IconComponent,
  subtitle,
  color = "hsl(var(--primary))",
  loading,
  testId,
}: MetricCardProps) {
  if (loading) {
    return (
      <Card className="p-4 md:p-6">
        <div className="animate-pulse">
          <div className="h-4 bg-muted rounded w-24 mb-4"></div>
          <div className="h-10 bg-muted rounded w-32 mb-2"></div>
          <div className="h-3 bg-muted rounded w-20"></div>
        </div>
      </Card>
    );
  }

  return (
    <Card className="p-4 md:p-6 hover-elevate transition-all duration-200">
      <div className="flex items-start justify-between gap-4">
        <div className="flex-1">
          <div className="text-xs md:text-sm font-medium text-muted-foreground uppercase tracking-wide mb-2">
            {title}
          </div>
          
          <div className="flex items-baseline gap-2 mb-1">
            <span 
              className="text-3xl md:text-4xl font-bold font-mono"
              style={{ color }}
              data-testid={testId}
            >
              {typeof value === "number" ? Math.round(value) : value}
            </span>
            {unit && (
              <span className="text-lg md:text-xl font-medium text-muted-foreground">
                {unit}
              </span>
            )}
          </div>
          
          {subtitle && (
            <div className="text-xs md:text-sm text-muted-foreground">
              {subtitle}
            </div>
          )}
        </div>

        <div className="flex-shrink-0">
          {icon && (
            <div 
              className="p-2 md:p-3 rounded-xl"
              style={{ backgroundColor: `${color}15` }}
            >
              <WeatherIcon type={icon} size={24} className="opacity-80" style={{ color }} />
            </div>
          )}
          {IconComponent && (
            <div 
              className="p-2 md:p-3 rounded-xl"
              style={{ backgroundColor: `${color}15` }}
            >
              <IconComponent size={24} className="opacity-80" style={{ color }} />
            </div>
          )}
        </div>
      </div>
    </Card>
  );
}
