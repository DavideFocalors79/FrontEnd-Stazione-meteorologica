import { Card } from "@/components/ui/card";
import { WeatherData } from "@shared/schema";
import { useSettings } from "@/contexts/SettingsContext";
import { convertTemperature, formatTime, formatDate } from "@/lib/weatherUtils";
import { translations } from "@/lib/translations";
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from "recharts";

interface WeatherChartProps {
  data: WeatherData[];
  type: "hourly" | "daily";
  metric: "temperature" | "humidity" | "pressure";
  loading?: boolean;
}

export function WeatherChart({ data, type, metric, loading }: WeatherChartProps) {
  const { settings } = useSettings();
  const t = translations[settings.language];

  if (loading || data.length === 0) {
    return (
      <Card className="p-6">
        <div className="animate-pulse">
          <div className="h-6 bg-muted rounded w-48 mb-6"></div>
          <div className="h-64 bg-muted rounded"></div>
        </div>
      </Card>
    );
  }

  const title = type === "hourly" ? t.hourlyForecast : t.weeklyForecast;
  
  const chartData = data.map((item) => ({
    time: type === "hourly" ? formatTime(new Date(item.timestamp)) : formatDate(new Date(item.timestamp), settings.language),
    value:
      metric === "temperature"
        ? convertTemperature(item.temperature, settings.temperatureUnit)
        : metric === "humidity"
        ? item.humidity
        : item.pressure,
    humidity: item.humidity,
    pressure: item.pressure,
  }));

  const getColor = () => {
    switch (metric) {
      case "temperature":
        return "hsl(15 90% 55%)";
      case "humidity":
        return "hsl(180 60% 50%)";
      case "pressure":
        return "hsl(270 50% 60%)";
    }
  };

  const getUnit = () => {
    switch (metric) {
      case "temperature":
        return settings.temperatureUnit === "celsius" ? "°C" : "°F";
      case "humidity":
        return "%";
      case "pressure":
        return settings.pressureUnit;
    }
  };

  const getLabel = () => {
    switch (metric) {
      case "temperature":
        return t.temperature;
      case "humidity":
        return t.humidity;
      case "pressure":
        return t.pressure;
    }
  };

  return (
    <Card className="p-4 md:p-6" data-testid={`chart-${type}-${metric}`}>
      <h3 className="text-lg md:text-xl font-semibold mb-6 text-foreground">
        {title} - {getLabel()}
      </h3>

      <ResponsiveContainer width="100%" height={280}>
        <AreaChart
          data={chartData}
          margin={{ top: 10, right: 10, left: 0, bottom: 0 }}
        >
          <defs>
            <linearGradient id={`color-${metric}`} x1="0" y1="0" x2="0" y2="1">
              <stop offset="5%" stopColor={getColor()} stopOpacity={0.3} />
              <stop offset="95%" stopColor={getColor()} stopOpacity={0} />
            </linearGradient>
          </defs>
          <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" opacity={0.3} />
          <XAxis
            dataKey="time"
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
            tickLine={false}
            axisLine={false}
          />
          <YAxis
            stroke="hsl(var(--muted-foreground))"
            fontSize={12}
            tickLine={false}
            axisLine={false}
            tickFormatter={(value) => `${Math.round(value)}${getUnit()}`}
          />
          <Tooltip
            contentStyle={{
              backgroundColor: "hsl(var(--card))",
              border: "1px solid hsl(var(--border))",
              borderRadius: "0.5rem",
              color: "hsl(var(--foreground))",
            }}
            formatter={(value: number) => [`${Math.round(value)}${getUnit()}`, getLabel()]}
          />
          <Area
            type="monotone"
            dataKey="value"
            stroke={getColor()}
            strokeWidth={2}
            fill={`url(#color-${metric})`}
            animationDuration={800}
          />
        </AreaChart>
      </ResponsiveContainer>
    </Card>
  );
}
