import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Settings, Download, Moon, Sun, MapPin } from "lucide-react";
import { SettingsDialog } from "./SettingsDialog";
import { ExportDialog } from "./ExportDialog";
import { useSettings } from "@/contexts/SettingsContext";
import { translations } from "@/lib/translations";
import { WeatherData } from "@shared/schema";

interface HeaderProps {
  weatherData: WeatherData[];
  lastUpdate?: Date;
}

export function Header({ weatherData, lastUpdate }: HeaderProps) {
  const { settings, updateSettings } = useSettings();
  const t = translations[settings.language];
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [exportOpen, setExportOpen] = useState(false);
  const [timeAgo, setTimeAgo] = useState("");

  useEffect(() => {
    if (!lastUpdate) return;

    const updateTimeAgo = () => {
      const seconds = Math.floor((new Date().getTime() - lastUpdate.getTime()) / 1000);
      if (seconds < 60) setTimeAgo(`${seconds}s fa`);
      else if (seconds < 3600) setTimeAgo(`${Math.floor(seconds / 60)}m fa`);
      else setTimeAgo(`${Math.floor(seconds / 3600)}h fa`);
    };

    updateTimeAgo();
    const interval = setInterval(updateTimeAgo, 10000);
    return () => clearInterval(interval);
  }, [lastUpdate]);

  const toggleTheme = () => {
    updateSettings({ theme: settings.theme === "dark" ? "light" : "dark" });
  };

  return (
    <>
      <header className="sticky top-0 z-50 border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 md:px-6 lg:px-8">
          <div className="flex h-16 items-center justify-between gap-4">
            {/* Logo and station info */}
            <div className="flex items-center gap-3">
              <div className="flex items-center gap-2">
                <div className="h-8 w-8 rounded-lg bg-primary/10 flex items-center justify-center">
                  <MapPin className="text-primary" size={18} />
                </div>
                <div>
                  <h1 className="text-lg font-bold font-display text-foreground" data-testid="text-station-name">
                    {settings.stationName}
                  </h1>
                  {settings.stationLocation && (
                    <p className="text-xs text-muted-foreground" data-testid="text-station-location">{settings.stationLocation}</p>
                  )}
                </div>
              </div>
            </div>

            {/* Center - Last update indicator */}
            <div className="hidden md:flex items-center gap-2">
              {lastUpdate && (
                <>
                  <div className="h-2 w-2 rounded-full bg-weather-success animate-pulse" data-testid="indicator-live" />
                  <span className="text-sm text-muted-foreground" data-testid="text-last-update">
                    {t.lastUpdate}: {timeAgo}
                  </span>
                </>
              )}
            </div>

            {/* Right - Actions */}
            <div className="flex items-center gap-2">
              <Button
                variant="ghost"
                size="icon"
                onClick={toggleTheme}
                data-testid="button-theme-toggle"
              >
                {settings.theme === "dark" ? <Sun size={20} /> : <Moon size={20} />}
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => setExportOpen(true)}
                data-testid="button-export"
              >
                <Download size={20} />
              </Button>

              <Button
                variant="ghost"
                size="icon"
                onClick={() => setSettingsOpen(true)}
                data-testid="button-settings"
              >
                <Settings size={20} />
              </Button>
            </div>
          </div>
        </div>
      </header>

      <SettingsDialog open={settingsOpen} onOpenChange={setSettingsOpen} />
      <ExportDialog open={exportOpen} onOpenChange={setExportOpen} data={weatherData} />
    </>
  );
}
