import { useState } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { UserSettings } from "@shared/schema";
import { useSettings } from "@/contexts/SettingsContext";
import { translations } from "@/lib/translations";
import { Moon, Sun } from "lucide-react";

interface SettingsDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export function SettingsDialog({ open, onOpenChange }: SettingsDialogProps) {
  const { settings, updateSettings } = useSettings();
  const t = translations[settings.language];
  const [localSettings, setLocalSettings] = useState<UserSettings>(settings);

  const handleSave = () => {
    updateSettings(localSettings);
    onOpenChange(false);
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl">{t.settings}</DialogTitle>
        </DialogHeader>

        <Tabs defaultValue="units" className="w-full">
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="units">{t.units}</TabsTrigger>
            <TabsTrigger value="appearance">{t.appearance}</TabsTrigger>
            <TabsTrigger value="general">{t.general}</TabsTrigger>
          </TabsList>

          <TabsContent value="units" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>{t.temperatureUnit}</Label>
              <Select
                value={localSettings.temperatureUnit}
                onValueChange={(value) =>
                  setLocalSettings({ ...localSettings, temperatureUnit: value as "celsius" | "fahrenheit" })
                }
              >
                <SelectTrigger data-testid="select-temperature-unit">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="celsius">Celsius (°C)</SelectItem>
                  <SelectItem value="fahrenheit">Fahrenheit (°F)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t.speedUnit}</Label>
              <Select
                value={localSettings.speedUnit}
                onValueChange={(value) =>
                  setLocalSettings({ ...localSettings, speedUnit: value as "kmh" | "mph" })
                }
              >
                <SelectTrigger data-testid="select-speed-unit">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="kmh">km/h</SelectItem>
                  <SelectItem value="mph">mph</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t.pressureUnit}</Label>
              <Select
                value={localSettings.pressureUnit}
                onValueChange={(value) =>
                  setLocalSettings({ ...localSettings, pressureUnit: value as "hpa" | "inHg" })
                }
              >
                <SelectTrigger data-testid="select-pressure-unit">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="hpa">hPa</SelectItem>
                  <SelectItem value="inHg">inHg</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>{t.precipitationUnit}</Label>
              <Select
                value={localSettings.precipitationUnit}
                onValueChange={(value) =>
                  setLocalSettings({ ...localSettings, precipitationUnit: value as "mm" | "inches" })
                }
              >
                <SelectTrigger data-testid="select-precipitation-unit">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mm">mm</SelectItem>
                  <SelectItem value="inches">inches</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="appearance" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>Tema</Label>
              <div className="grid grid-cols-2 gap-4">
                <Button
                  variant={localSettings.theme === "light" ? "default" : "outline"}
                  onClick={() => setLocalSettings({ ...localSettings, theme: "light" })}
                  className="h-auto py-4 flex flex-col gap-2"
                  data-testid="button-theme-light"
                >
                  <Sun size={24} />
                  <span>{t.lightMode}</span>
                </Button>
                <Button
                  variant={localSettings.theme === "dark" ? "default" : "outline"}
                  onClick={() => setLocalSettings({ ...localSettings, theme: "dark" })}
                  className="h-auto py-4 flex flex-col gap-2"
                  data-testid="button-theme-dark"
                >
                  <Moon size={24} />
                  <span>{t.darkMode}</span>
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label>{t.language}</Label>
              <Select
                value={localSettings.language}
                onValueChange={(value) =>
                  setLocalSettings({ ...localSettings, language: value as "it" | "en" })
                }
              >
                <SelectTrigger data-testid="select-language">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="it">Italiano</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </TabsContent>

          <TabsContent value="general" className="space-y-4 py-4">
            <div className="space-y-2">
              <Label>{t.stationName}</Label>
              <Input
                value={localSettings.stationName || ""}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, stationName: e.target.value })
                }
                data-testid="input-station-name"
              />
            </div>

            <div className="space-y-2">
              <Label>{t.stationLocation}</Label>
              <Input
                value={localSettings.stationLocation || ""}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, stationLocation: e.target.value })
                }
                placeholder="es. Milano, Italia"
                data-testid="input-station-location"
              />
            </div>

            <div className="space-y-2">
              <Label>{t.updateInterval} (minuti)</Label>
              <Input
                type="number"
                value={localSettings.updateInterval}
                onChange={(e) =>
                  setLocalSettings({ ...localSettings, updateInterval: parseInt(e.target.value) })
                }
                min={1}
                max={1440}
                data-testid="input-update-interval"
              />
              <p className="text-xs text-muted-foreground">
                Frequenza di aggiornamento automatico dei dati (1-1440 minuti)
              </p>
            </div>
          </TabsContent>
        </Tabs>

        <div className="flex justify-end gap-2 pt-4 border-t">
          <Button variant="outline" onClick={() => onOpenChange(false)} data-testid="button-cancel-settings">
            {t.cancel}
          </Button>
          <Button onClick={handleSave} data-testid="button-save-settings">
            {t.save}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
